n = 20 //br changed. or:15, 20 Number of players

nAi = 19 //br changed,or:0, nAi = 19//0 for production 4human11AI

nRounds = 4 //br changed, or:15 for production


perList = [:]  //br store the persentage the player recieved from the neighbors
tn = 4000  //  br control the timer. tn up ,the time longer. this time is the interface jump time factor.
tn1=1*30*1000   //br:ready time to min*second*1000   labtesting use:1*60*1000 
timeIdle = 1*60*1000 //br: this is the Idle time for players. change it from 45s to 20mins.


connectivity = 0.3d // 0.3d graph density (0 - 1) br: for less testing players seting it to be 0.5d
maxDensity = 0.25d //0.25d

showInformation = 0 // 0->info, 1->total received points, 2->degree

geoID = 0 // 0: create a graph from scratch, 1-10: create a graph from a geo file

isSurvey = true
removeDropped = true

bonusRatio = 0.005d //bonus = total bandwidth * bonusRatio

//br:flexable resource:: 
//resourceInit  = 30  //   br:points players can share every round
//varianceInit = 20 //br variance to adjust daily resource

variance = 20//br: variance for the max value. varianceInit //* Math.random() * ((r.nextDouble() < 0.5) ? -1 : 1)    
resource = 30//br: the mean of the resource. resourceInit //+ Math.random() * ((r.nextDouble() < 0.5) ? -1 : 1)
//lastTotalbr = 0


extraBonus = 2.5

startAt = null

numLogin = 0
numPass = 0
numCompleted = 0

//xu: record the remaining resources of the current player
remaining = 0



def getSubmitForm(assignmentId, bonus, reason) {
  
  // Change www.mturk.com to workersandbox.mturk.com when testing in sandbox
  def returnString = """<form action="https://www.mturk.com/mturk/externalSubmit" method="get">"""
  
  //if (reason == "GameEnd") {
  //  returnString += """<p>Please let us know what your strategy was and how you felt your neighbors.</p>
  //    <textarea name="strategy" rows="5" cols="50"></textarea>"""
  //}
  
  returnString += """<div style="text-align: center;"><button type="submit" style="text-align: center;">Submit HIT</button></div> 
				<input type="hidden" name="assignmentId" value="${assignmentId}"/> 
				<input type="hidden" name="bonus" value="${bonus}" />
				<input type="hidden" name="reason" value="${reason}" />
              </form>"""
  return returnString
}


def getSubmitFormShort(assignmentId, bonus, reason) {
  
  // Change www.mturk.com to workersandbox.mturk.com when testing in sandbox
  def returnString = """<form action="https://www.mturk.com/mturk/externalSubmit" method="get">"""
  
  if (reason == "GameEnd") {
    returnString += """<p><b>Q8. How do you feel about the game?</b></p>
      <textarea name="strategy" rows="5" cols="50"></textarea>"""
  }
  
  returnString += """<div style="text-align: center;"><button type="submit" style="text-align: center;">Submit HIT</button></div> 
				<input type="hidden" name="assignmentId" value="${assignmentId}"/> 
				<input type="hidden" name="bonus" value="${bonus}" />
				<input type="hidden" name="reason" value="${reason}" />
              </form>"""
  return returnString
}


def createGraph(){

  Graph tempGraph = new TinkerGraph();
  for (int i = 0; i < n; i++) {
    tempGraph.addVertex(i)
  }

  if (network == 0){
    singleGeometricRandom(tempGraph)
  }else if ((network == 1) || (network == 3)){
  	lowExchageNetwork(tempGraph)
  }else if ((network == 2) || (network == 4)){
    highExchageNetwork(tempGraph)
  }
    
  
  // Record degree of vertices
  //tempGraph.V.each { v ->
  //  v.degree = v.neighbors.count()
  //}
  def tempGraphVertices = tempGraph.V.toList()

  def players = g.V.filter{ (it.active != null) && (it.active)}.shuffle.toList()

  // Assign player IDs to tempGraph vertices	
  for (int i = 0; i < n; i++) {
    
    def p = players.get(i)
    tempGraphVertices.get(i).realId = p.id
    //g.getVertex(p.id).posX = tempGraphVertices.get(i).posX
	//g.getVertex(p.id).posY = tempGraphVertices.get(i).posY
    g.getVertex(p.id).nodeLabel = tempGraphVertices.get(i).nodeLabel
    //g.getVertex(p.id).label = tempGraphVertices.get(i).label
    
    
    //println("Assigning player " + p.id + " to vertice with degree " + tempGraphVertices.get(i).degree)
    
  }

  // Add edges
  tempGraph.E.each { tempEdge ->
    g.addTrackedEdge(g.getVertex(tempEdge.getVertex(Direction.OUT).realId), g.getVertex(tempEdge.getVertex(Direction.IN).realId), "connected")
  }

}

def singleGeometricRandom(graph){
  List players = graph.getVertices().iterator().toList()
  Random rand = new Random()
  def isSubgraph = 1
  def gcount = 0
  while((isSubgraph == 1) && (gcount < 30)){

    a.addEvent("CreateGraph", ["count" : gcount])
    println(gcount)
  
    if (gcount > 0){
	  graph.getEdges().each({
        graph.removeEdge(it)
      })
    }

    def gid = 0
    def label = 'A'
    for (i in 0..(n - 1)) {
      def p = players.get(i)
      p.setProperty("posX", rand.nextDouble())
      p.setProperty("posY", rand.nextDouble())
      //p.setProperty("even", (i % 2 == 0))
      p.setProperty("gid", gid++)
      p.setProperty("nodeLabel", label++)
    }
    
    def numEdges = 0
    for (i in 0..(n - 2)) {
      def p1 = players.get(i)
      for (j in (i + 1)..(n - 1)) {
        def p2 = players.get(j)
        def d = (p1.posX - p2.posX)**2 + (p1.posY - p2.posY)**2
        if (d <= (connectivity**2)) {
          //addTrackedEdge(p1, p2, "connected")
          graph.addEdge(p1, p2, "connected")
          //p1.connected = 1
          //p2.connected = 1
          numEdges++
        }
      }
    }
    
  

    def isChange = 1  
    while (isChange == 1){
      isChange = 0
      graph.E.each {edge->

        if(edge.inV.next().gid < edge.outV.next().gid) {
          edge.outV.next().gid = edge.inV.next().gid
      	  isChange = 1
        }else if (edge.inV.next().gid > edge.outV.next().gid) {
          edge.inV.next().gid = edge.outV.next().gid
      	  isChange = 1
        }
      }
    }
    
    

    if ((numEdges*2/(n*(n-1))) < maxDensity){
      isSubgraph = 0
      for (i in 0..(n - 1)) {
        if (players.get(i).gid != 0){
          isSubgraph = 1
          break
        }
      }
    }

    gcount++
   
  } //while((isSubgraph == 1) && (gcount < 100)){

}

def geometricRandomFromFile(graph){
  List players = graph.getVertices().iterator().toList()
  Random rand = new Random()

  a.addEvent("CreateGraphFromFile", ["geoID" : geoID])
   
  
  def filename = "csv/geo2/info_" + showInformation.toString() + "/geo_" + geoID.toString() + ".csv"
  def count = 0
  new File(filename).splitEachLine(","){line->
    if (count > 0){
    
      def p =players.get(count-1)
      p.setProperty("posX", line[0].toDouble())
      p.setProperty("posY", line[1].toDouble())
      p.setProperty("gid", count-1)
      p.setProperty("nodeLabel", line[2])
      //println(p.nodeLabel)
    }
    count++
        
  }
  /*
  def gid = 0
  for (i in 0..(n - 1)) {
    def p = players.get(i)
    p.setProperty("posX", rand.nextDouble())
    p.setProperty("posY", rand.nextDouble())
    //p.setProperty("even", (i % 2 == 0))
    p.setProperty("gid", gid++)
  }
  */  

  for (i in 0..(n - 2)) {
    def p1 = players.get(i)
    for (j in (i + 1)..(n - 1)) {
      def p2 = players.get(j)
      def d = (p1.posX - p2.posX)**2 + (p1.posY - p2.posY)**2
      if (d <= (connectivity**2)) {
        //addTrackedEdge(p1, p2, "connected")
        graph.addEdge(p1, p2, "connected")
        //p1.connected = 1
        //p2.connected = 1
      }
    }
  }
    

}

def lowExchageNetwork(graph){
  List players = graph.getVertices().iterator().toList()
  
  def filename = "csv/elist/low_exchange.csv" //TMP
  //def count = 0
  new File(filename).splitEachLine(","){line->
    def p1 = players.get(line[0].toInteger()-1)
    def p2 = players.get(line[1].toInteger()-1)
    graph.addEdge(p1, p2, "connected")     
        
  }
  
  def label = 'A'
  for (i in 0..(n - 1)) {
    def p = players.get(i)
    p.setProperty("nodeLabel", label++)
  }
  
}

def highExchageNetwork(graph){
  List players = graph.getVertices().iterator().toList()
  
  def filename = "csv/elist/high_exchange.csv" //TMP
  //def count = 0
  new File(filename).splitEachLine(","){line->
    def p1 = players.get(line[0].toInteger()-1)
    def p2 = players.get(line[1].toInteger()-1)  
    graph.addEdge(p1, p2, "connected")     
        
  }
  
  def label = 'A'
  for (i in 0..(n - 1)) {
    def p = players.get(i)
    p.setProperty("nodeLabel", label++)
  }
}