
sharingStep = stepFactory.createStep()
  

sharingStep.run = {
  println("Round: " + curRound)
  println "sharingStep.run"
  curStep = "SharingStep"

  a.addEvent("ShareStart", ["round" : curRound])
  g.V.filter{it.active}.each { player->
  	player.evening = false
  }
  
  
  //println ('old perList,same to above' + perList) //br: check the perlist
  
  g.V.filter{it.active}.each { player->
    
  //br: deal with players seperatly: real players & AI players, btw the AI part is in initial part, not here.
  	
    if (!player.ai){  //br: for real players, show the form to fill with
	    player.showAllocations = true
    	player.waitAllocations = false
    	player.resultAllocations = false
    
        //br: give flexible player.resource
          k = Math.random()  
          kk = (( k < 0.5) ? -1 : 1) * k//get a random -1~1 number

         player.variance = variance * kk    
         player.resource = Math.round(resource + player.variance-0.5)  //br: (resource + player.variance)
         //println('variance resource:     ' + player.resource) //br: check value of resource
        // player.roundTotal =0  forgot why I add this parameter, but keep it. 
      	
      
         //xu: initiate the remaining variable if the current round = 1
        if (curRound == 1){
           player.remaining = 0
        }
          
      
      	 //xu:check the real player resource got today
         println('!!real player round '+curRound +' variance resource: ' + player.resource)
      
      	 
      	 //xu:update the total resources of the current real player
      	 player.resource += player.remaining
      
      	 //xu:update the number of remaining resources
      
      	 player.remaining = player.resource
      
      	 println('!!real player round '+curRound +' total resource: ' + player.resource)
    
    	 player.text = c.get("Sharing", player.point, curRound, currency.format(player.point * bonusRatio))
    }
    
    player.text2 = "You cannot push the Share button until you fill ALL the boxes with a number. If you don't want to give Internet to a certain neighbor, you have to enter the number 0."
    
    
    //xu:the below part is applied to all players
    
    a.add(player, [
      name: "Share",
      //custom: customTable,
      result: { params->
        //println('allocation for each neighour start++++++++++++++++++')
        //println('params:'+params)
        def data = ["pid": player.id,
                    "resource" : player.resource,                   
                    "round" : curRound]
        //println(player.id)
        params.each { k, v ->   
          //println('loopstart=======================================')
          //Roundbr = 0
          if (v instanceof Integer) {
          }else{
          	 v = Float.valueOf(v).toInteger() //br: get value from string
            //v = Integer.decode(v)
          }
          data[k] = v
          def neighbor = g.getVertex(k)
          if (neighbor != null) {
 
            neighbor.toAdd += v
              
            player["n" + k].totalTemp += v 
            player["n" + k].lastRoundTemp = v
            
            
            //xu: every time the current play give his resources to a neighbour, the variable should decrease
            player.remaining -= v
            
            

            
            
            //println('============================================')//br: check var
            //println('after +v, after_neighoor.toAdd:  '+ neighbor.toAdd )
            //println('after_player["n" + k].totalTemp+'+player["n" + k].totalTemp)
            //println('after_player["n" + k].lastRoundTemp'+player["n" + k].lastRoundTemp)) 
            
           // println('loopfinish=======================================')
          }
		}
        
        //xu: after sharing, print the remained resources
        println('==========round '+curRound+' over,player '+ player.id + ' remained: '+ player.remaining + '==========')
        
        
        
       // println('block finish++++++++++++++')
        player.showAllocations = false
        player.waitAllocations = true  //br: night result show to players
        player.resultAllocations = false

        player.text2 = "<p><strong>Please wait... other players are under consideration.</strong></p>"
		
        //Animation of giving bandwidth
        player.neighbors.each { neighbor->
          if (player["n" + neighbor.getId()].lastRoundTemp > 0){
	        //br: fix the animate, rewrite as:
            g.getEdge(player, neighbor).private(player, ["animate" : curRound + "," + player["n" + neighbor.getId()].lastRoundTemp + "," + player.getId() + "," + neighbor.getId() ])        
    
          
          }
          
        }
        
       /*
           //Animation of giving bandwidth//br: this from tutorial part, put here to compare the difference from the above part.
    player.neighbors.each { neighbor->
      if (player["n" + neighbor.getId()].lastRoundTemp > 0){
	    g.getEdge(player, neighbor).private(player, ["animate" : player["n" + neighbor.getId()].lastRoundTemp + "," + player.getId() + "," + neighbor.getId() + ",p1"])
      }
    }
       
       
       
       */
        
        /*if (!player.ai){
        
          println ('human before in the data form:   ' + player.toAdd)
        }*/ //br: check the data before put it into forms      
        
        
        a.addEvent("distributeBW", data)  
        
        
      }
    ])
  } //br: iteration every player
}  

sharingStep.done = {
  println "sharingStep.done"
  def timer = new Timer()
  def startResultStep = timer.runAfter(tn) {//br: time between allocation and show result. could short
	  resultStep.start()
  }
}
