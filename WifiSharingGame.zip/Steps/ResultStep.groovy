
resultStep = stepFactory.createStep("resultStep")

resultStep.run = {
  println "resultStep.run"
  a.addEvent("ResultStart",["round" : curRound])
  

  
  g.V.filter{it.active}.each { player->
    player.evening = true
    player.neighbors.each { neighbor->
      player["n" + neighbor.id].total = player["n" + neighbor.id].totalTemp
      player["n" + neighbor.id].lastRound = player["n" + neighbor.id].lastRoundTemp
      
      //Animation of giving bandwidth
      if (!player.ai){   
	    if (neighbor["n" + player.getId()].lastRoundTemp > 0){
		       // br: rewrite this part:
           
		  g.getEdge(player, neighbor).private(player, ["animate" : curRound + "," +neighbor["n" + player.getId()].lastRoundTemp + "," + neighbor.getId() + "," + player.getId()  ])        
     
         
        }
      }
      
      

    }
  }
  

    
  g.V.filter{it.active}.each {player->
  //g.V.filter{it.active && ((it.ai == null) || (it.ai != 1)) }.each { player->
    
    
    player.point += player.toAdd
    
    player.text2 = ""
    
    if (showInformation == 1){
      player.score2 = player.point
    }
    
    if (!player.ai){
      player.showAllocations = false
      player.waitAllocations = false
      player.resultAllocations = true
      player.text = c.get("Result", player.point, curRound, currency.format(player.point * bonusRatio))	  
    }
    
    if (!player.ai){
      a.add(player, [
        name: "Next",
        //custom: customTable,
        result: { 
          player.text2 = "<p><strong>Please wait... other players are under consideration.</strong></p>"

         /* a.addEvent("ResultConfirmed",["pid" : player.id,
                                        "round" : curRound,
                                        "received" : player.toAdd])*/
        }
      ])
    }
    
    a.addEvent("ResultConfirmed",["pid" : player.id,
                                      "round" : curRound,
                                      "received" : player.toAdd])
    
    //player.toAdd = 0  //br: player.toAdd is temperate to store the point from neighbor, move this reseting it to 0 after calculate the 
    //println ('recieved 0??:    ' + player.toAdd)

  } 
  

  //s=================================br: record the percentage of each neighbor giving to the AI into perList.
  g.V.filter{it.active}.each { player->  
    
    fm = player.toAdd  // br: every round player get total points(from all neighbors)
          //println ('player ' + player.getId() + '  last round recieved point:' + fm)  //br: check the var fm 
    
    player.neighbors.each { neighbor->
     
   
	    if (neighbor["n" + player.getId()].lastRound >= 0){
    
          //println ('player ' + player.getId() + '  last round recieved point:' + fm)           

          
          def fz = neighbor["n" + player.getId()].lastRound  //br: the points from the single neigbhor in recently round.
          def per = fz / fm   //br: the percentage 
          
          //println ('neighbor / player:  ' + per)  // br: check the value of var per
          
          pid = player.getId()   //br: get the player id
          nid = neighbor.getId()  // br: get the neighbor id
 
         // br: List of percentage. the key = "round_" + curRound + "pid_" + pid + "nid_" +nid
          
          perList[("round_" + curRound + "pid_" + pid + "nid_" +nid)]= per
          
          //println ('perList' + perList) //br: check the perList
          
        }    
    }
  }  
  

  
     
  g.V.filter{it.active}.each {player->  //br: reset the var player.toAdd = 0 for recording the points in next round
  
    player.toAdd = 0

  } 
   
 //===================================end  

} //result.run

resultStep.done = {
  
  if (curRound < nRounds) {
    curRound++
    sharingStep.start()
  } else {
    println("endGameTask")
    a.setDropPlayers(false)
    a.addEvent("GameEnd", ["round" : curRound])
    finishGame()
  }
}

def finishGame(){
  g.V.filter{(it.active) && ((it.ai == null) || (it.ai != 1)) }.each { player ->
    player.text2 = ""
    player.resultAllocations = false
    player.evening = false

    //player.text = c.get("GameEnd", player.point, currency.format(player.point * bonusRatio), getSubmitForm(player.id, player.point * bonusRatio, "GameEnd"))
	a.addEvent("PlayerBonus", ["pid" : player.id,
                               "bonus": (player.point * bonusRatio).round(2),
                               "totalBonus": ((player.point * bonusRatio) + extraBonus).round(2)])
    
    
    if (isSurvey == true){
      player.text = c.get("GameEnd1", currency.format(player.point * bonusRatio))
      a.add(player, [name: "Next", result: {  
    	player.text = c.get("Survey11")
      }])
      
      def radioText11 = """<div align="left">
             <input type="radio" class="param survey" name="satisfaction1" value="7"/> Strongly agree<br>
			 <input type="radio" class="param survey" name="satisfaction1" value="6"/> Agree<br>
			 <input type="radio" class="param survey" name="satisfaction1" value="5"/> Slightly agree<br>
			 <input type="radio" class="param survey" name="satisfaction1" value="4"/> Neither agree nor disagree<br>
			 <input type="radio" class="param survey" name="satisfaction1" value="3"/> Slightly disagree<br>
			 <input type="radio" class="param survey" name="satisfaction1" value="2"/> Disagree<br>
			 <input type="radio" class="param survey" name="satisfaction1" value="1"/> Strongly disagree<br>
           </div>"""
      
       a.add(player, 
              [name: "Next", 
               custom: radioText11,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 player.text = c.get("Survey12")
       }])
      
      
      def radioText12 = """<div align="left">
             <input type="radio" class="param survey" name="satisfaction2" value="7"/> Strongly agree<br>
			 <input type="radio" class="param survey" name="satisfaction2" value="6"/> Agree<br>
			 <input type="radio" class="param survey" name="satisfaction2" value="5"/> Slightly agree<br>
			 <input type="radio" class="param survey" name="satisfaction2" value="4"/> Neither agree nor disagree<br>
			 <input type="radio" class="param survey" name="satisfaction2" value="3"/> Slightly disagree<br>
			 <input type="radio" class="param survey" name="satisfaction2" value="2"/> Disagree<br>
			 <input type="radio" class="param survey" name="satisfaction2" value="1"/> Strongly disagree<br>
           </div>"""
      
       a.add(player, 
              [name: "Next", 
               custom: radioText12,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 player.text = c.get("Survey13")
       }])


      def radioText13 = """<div align="left">
             <input type="radio" class="param survey" name="satisfaction3" value="7"/> Strongly agree<br>
			 <input type="radio" class="param survey" name="satisfaction3" value="6"/> Agree<br>
			 <input type="radio" class="param survey" name="satisfaction3" value="5"/> Slightly agree<br>
			 <input type="radio" class="param survey" name="satisfaction3" value="4"/> Neither agree nor disagree<br>
			 <input type="radio" class="param survey" name="satisfaction3" value="3"/> Slightly disagree<br>
			 <input type="radio" class="param survey" name="satisfaction3" value="2"/> Disagree<br>
			 <input type="radio" class="param survey" name="satisfaction3" value="1"/> Strongly disagree<br>
           </div>"""
      
       a.add(player, 
              [name: "Next", 
               custom: radioText13,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 player.text = c.get("Survey14")
       }])
      
      
      def radioText14 = """<div align="left">
             <input type="radio" class="param survey" name="satisfaction4" value="7"/> Strongly agree<br>
			 <input type="radio" class="param survey" name="satisfaction4" value="6"/> Agree<br>
			 <input type="radio" class="param survey" name="satisfaction4" value="5"/> Slightly agree<br>
			 <input type="radio" class="param survey" name="satisfaction4" value="4"/> Neither agree nor disagree<br>
			 <input type="radio" class="param survey" name="satisfaction4" value="3"/> Slightly disagree<br>
			 <input type="radio" class="param survey" name="satisfaction4" value="2"/> Disagree<br>
			 <input type="radio" class="param survey" name="satisfaction4" value="1"/> Strongly disagree<br>
           </div>"""
      
       a.add(player, 
              [name: "Next", 
               custom: radioText14,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 player.text = c.get("Survey15")
       }])  
      
      
      def radioText15 = """<div align="left">
             <input type="radio" class="param survey" name="satisfaction5" value="7"/> Strongly agree<br>
			 <input type="radio" class="param survey" name="satisfaction5" value="6"/> Agree<br>
			 <input type="radio" class="param survey" name="satisfaction5" value="5"/> Slightly agree<br>
			 <input type="radio" class="param survey" name="satisfaction5" value="4"/> Neither agree nor disagree<br>
			 <input type="radio" class="param survey" name="satisfaction5" value="3"/> Slightly disagree<br>
			 <input type="radio" class="param survey" name="satisfaction5" value="2"/> Disagree<br>
			 <input type="radio" class="param survey" name="satisfaction5" value="1"/> Strongly disagree<br>
           </div>"""
      
       a.add(player, 
              [name: "Next", 
               custom: radioText15,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 player.text = c.get("Survey16")
       }])       
      
      
      //def cblist1 = [0, 1, 2, 3, 4, 5, 6, 7, 8]
	  //Collections.shuffle(alist)
  
  	  def cbAnswers1 = ["""<input type="checkbox" class="param survey" name="goal" value="a1_earn_max"/> to earn as much as possible.<br>""",
		  		       """<input type="checkbox" class="param survey" name="goal" value="a2_fair"/> to be fair to my neighbors.<br>""",
         			   """<input type="checkbox" class="param survey" name="goal" value="a3_make_equal"/> to make everyone earn equally.<br>""",
			           """<input type="checkbox" class="param survey" name="goal" value="a4_earn_more"/> to earn more than others.<br>""",
			           """<input type="checkbox" class="param survey" name="goal" value="a5_help"/> to help my neighbors in need.<br>""",
			           """<input type="checkbox" class="param survey" name="goal" value="a6_make_fair"/> to make my neighbors play fair.<br>""",
			           """<input type="checkbox" class="param survey" name="goal" value="a7_enjoy"/> to enjoy the game.<br>""",
                       """<input type="checkbox" class="param survey" name="goal" value="a8_quick"/> to complete the game as quickly as possible.<br>"""]
      
      Collections.shuffle(cbAnswers1)
      def checkboxText1 = """<div align="left">"""
      for (ans in cbAnswers1){
        checkboxText1 += ans
      }
      checkboxText1 += """<input type="checkbox" class="param survey" name="goal" value="a9_others"/> other.<br></div>"""
      
      /*
      checkboxText1 = """<div align="left">
             <input type="checkbox" class="param survey" name="goal" value="a1_earn_max"/> to earn as much as possible.<br>
			 <input type="checkbox" class="param survey" name="goal" value="a2_fair"/> to be fair to my neighbors.<br>
			 <input type="checkbox" class="param survey" name="goal" value="a3_make_equal"/> to make everyone earn equally.<br>
			 <input type="checkbox" class="param survey" name="goal" value="a4_earn_more"/> to earn more than others.<br>
			 <input type="checkbox" class="param survey" name="goal" value="a5_help"/> to help my neighbors in need.<br>
			 <input type="checkbox" class="param survey" name="goal" value="a6_make_fair"/> to make my neighbors play fair.<br>
			 <input type="checkbox" class="param survey" name="goal" value="a7_enjoy"/> to enjoy the game.<br>
             <input type="checkbox" class="param survey" name="goal" value="a8_quick"/> to complete the game as quickly as possible.<br>
             <input type="checkbox" class="param survey" name="goal" value="a9_others"/> other.<br>
		  </div>"""
      */
      
      a.add(player, 
              [name: "Next", 
               custom: checkboxText1,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 player.text = c.get("Survey17")
       }]) 
      
      
      
      
      def cbAnswers2 = ["""<input type="checkbox" class="param survey" name="strategy" value="a1_reciprocate"/> I reciprocated the actions of my neighbors.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a2_use_relation"/> I took advantage of my neighbors.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a3_develop_relation"/> I developed a steady relationship with my neighbors.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a4_punish"/> I punished unpleasant players.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a5_help_disadvantaged"/> I gave more to the disadvantaged.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a6_help_powerful"/> I gave more to the powerful.<br>""",
                        """<input type="checkbox" class="param survey" name="strategy" value="a7_reputation"/> I built a good reputation and maintained it.<br>""",
                        """<input type="checkbox" class="param survey" name="strategy" value="a8_greedy"/> I kept looking for a way to earn more.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a9_risk_averse"/> I avoided the risk of earning less than I was already earning.<br>""",
			            """<input type="checkbox" class="param survey" name="strategy" value="a10_no_strategy"/> I had no specific strategy.<br>"""]
      
      Collections.shuffle(cbAnswers2)
      def checkboxText2 = """<div align="left">"""
      for (ans in cbAnswers2){
        checkboxText2 += ans
      }
      checkboxText2 += """<input type="checkbox" class="param survey" name="strategy" value="a11_other"/> Other.<br></div>"""
      
      
      /*
      checkboxText2 = """<div align="left">
             <input type="checkbox" class="param survey" name="strategy" value="a1_reciprocate"/> I reciprocated the actions of my neighbors.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a2_use_relation"/> I took advantage of my neighbors.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a3_develop_relation"/> I developed a steady relationship with my neighbors.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a4_punish"/> I punished unpleasant players.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a5_help_disadvantaged"/> I gave more to the disadvantaged.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a6_help_powerful"/> I gave more to the powerful.<br>
             <input type="checkbox" class="param survey" name="strategy" value="a7_reputation"/> I built a good reputation and maintained it.<br>
             <input type="checkbox" class="param survey" name="strategy" value="a8_greedy"/> I kept looking for a way to earn more.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a9_risk_averse"/> I avoided the risk of earning less than I was already earning.<br>
			 <input type="checkbox" class="param survey" name="strategy" value="a10_no_strategy"/> I had no specific strategy.<br>
             <input type="checkbox" class="param survey" name="strategy" value="a11_other"/> Other.<br>
		  </div>"""
      */
      
      a.add(player, 
              [name: "Next", 
               custom: checkboxText2,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("Survey", data)
                 numCompleted++;
                 println("Survey completed: " + numCompleted)
                
                 player.text = c.get("Survey18", currency.format(extraBonus), currency.format(player.point * bonusRatio), currency.format((player.point * bonusRatio) + extraBonus), getSubmitFormShort(player.id, ((player.point * bonusRatio) + extraBonus).round(2), "GameEnd"))
       }]) 
      
      
    /* //Old version
	   player.text = c.get("Survey1", currency.format(player.point * bonusRatio), currency.format(extraBonus), currency.format((player.point * bonusRatio) + extraBonus))
      
       radioText2 = """<div align="left">
             <input type="radio" class="param survey" name="game" value="very-satisfied"/><small> Very Satisfied</small>
             <input type="radio" class="param survey" name="game" value="satisfied"/><small> Satisfied</small>
	         <input type="radio" class="param survey" name="game" value="neither"/><small> Neither</small>
             <input type="radio" class="param survey" name="game" value="dissatisfied"/><small> Dissatisfied</small>
             <input type="radio" class="param survey" name="game" value="very-dissatisfied"/><small> Very Dissatisfied</small><br><br>
    	   </div>"""
      
       a.add(player, 
              [name: "Next", 
               custom: radioText2,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("GameSatisfaction", data)
                 player.text = c.get("Survey2", currency.format(player.point * bonusRatio), currency.format(extraBonus), currency.format((player.point * bonusRatio) + extraBonus))
       }])
      
      
      
       radioText = ""
    
       player.neighbors.sort{it.score}.each { neighbor->
         radioText += """<div align="left">
		   Neighbor <b>${neighbor.score}:</b><br>
             <input type="radio" class="param survey" name="nid-${neighbor.id}" value="very-satisfied"/><small> Very Satisfied</small>
             <input type="radio" class="param survey" name="nid-${neighbor.id}" value="satisfied"/><small> Satisfied</small>
	         <input type="radio" class="param survey" name="nid-${neighbor.id}" value="neither"/><small> Neither</small>
             <input type="radio" class="param survey" name="nid-${neighbor.id}" value="dissatisfied"/><small> Dissatisfied</small>
             <input type="radio" class="param survey" name="nid-${neighbor.id}" value="very-dissatisfied"/><small> Very Dissatisfied</small><br><br>
    	   </div>"""
      
       }
    
       a.add(player, 
              [name: "Next", 
               custom: radioText,
               result: { params->
                 def data = ["pid": player.id]
                 //println(params)
    	         params.each { k, v ->         
                   data[k] = v
                 }
                 a.addEvent("NeighborSatisfaction", data)
                 player.text = c.get("Survey3", currency.format(player.point * bonusRatio), currency.format(extraBonus), currency.format((player.point * bonusRatio) + extraBonus))
       }])
    
       a.add(player, 
              [name: "Next", 
               custom: """<div align="left"><textarea class="param survey" name="feeling" rows="8" cols="50"></textarea></div>""",
               result: { params->
                 a.addEvent("Strategy", ["pid":player.id, "comment":params.feeling])
                 player.text = c.get("Survey4", currency.format(player.point * bonusRatio), currency.format(extraBonus), currency.format((player.point * bonusRatio) + extraBonus))
       }])
    
       a.add(player, 
              [name: "Next", 
               custom: """<div align="left"><textarea class="param survey" name="strategy" rows="8" cols="50"></textarea></div>""",
               result: { params->
                 a.addEvent("Feeling", ["pid":player.id, "comment":params.strategy])
			     numCompleted++;
                 println("Survey completed: " + numCompleted)
                 player.text2 = ""
                 player.text = c.get("GameEnd", currency.format(player.point * bonusRatio), currency.format(extraBonus), currency.format((player.point * bonusRatio) + extraBonus), getSubmitForm(player.id, ((player.point * bonusRatio) + extraBonus).round(2), "GameEnd"))
       }])
	*/
      
    }else{
    	player.text = c.get("GameEnd", currency.format(player.point * bonusRatio), currency.format(extraBonus), currency.format((player.point * bonusRatio) + extraBonus), getSubmitFormShort(player.id, ((player.point * bonusRatio) + extraBonus).round(2), "GameEnd"))
    	a.remove(player)
    }
    
        
    
    //a.remove(player)
  }
	
}