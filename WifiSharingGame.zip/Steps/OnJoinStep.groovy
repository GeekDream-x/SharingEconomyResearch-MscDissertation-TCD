onJoinStep = stepFactory.createNoUserActionStep()

onJoinStep.run = { playerId->
  if (playerId && playerId.indexOf("_") == -1 ) {
    numLogin++
    println("onJoinStep.run: " + numLogin)
    def player = g.getVertex(playerId)
    player.score = ""
    player.private.score = ""
    player.point = 0
    player.showInformation = showInformation
    player.text = c.get("Welcome")
    player.active = false
    player.dropped = false
    player.passed = true
    player.passTest = false
    player.uid = player.id
    
   // flexible resource     
    k = Math.random()  
    kk = (( k < 0.5) ? -1 : 1) * k//br: get a random -1~1 number
    
    player.oriResource = resource  //br: the mean assign
    player.oriVariance = variance  //br: variance assign
    player.variance = variance * kk    //br: this round get the radom variance
    player.resource = Math.round(resource + player.variance - 0.5)  //br: this source of this round.

    
  
    /*//Timer setup to start a game  br: at demo,we commend out this part
    def curTime = new Date().getTime()
    if (startAt == null) {
  	  startAt = curTime + 1000000
    }
    g.addTimer("player": player, time: ((startAt - curTime)/1000).toInteger(), type: "time", appearance: "info", timerText: "The game will start in:", direction: "down", result: {})
    */
    a.add(player, 
        [
          name: "Begin",
          result: {
            //player.text = c.get("Tutorial1")
            player.private.score = "You"
            startTutorial(player)//br:defined at L56
          },
          event: [name: "StartedTutorial", data: [pid: player.id]]
    ])
 
  
  	/*
    a.add(player, 
        [
          name: "Next",
          result: {
            player.text = c.get("PleaseWait")
          }
    ])
    */
	
  }//if (playerId && playerId.indexOf("_") == -1 ) {
}

onJoinStep.done = {
  println "onJoinStep.done"
}

def startTutorial(player) {

  //Timer setup to start a game  
  //def curTime = new Date().getTime()
  //if (startAt == null) {
  //	startAt = curTime + 1000000
  //}
  //g.addTimer(time: ((startAt - curTime)/1000).toInteger(), type: "time", appearance: "info", timerText: "The game will start in:", direction: "down", result: {})
  
  
  def neighbor1
  def neighbor2
  def neighbor3
  
  neighbor1 = g.addVertex(player.id + "_1")
  neighbor1.active = false  
  neighbor1.score = "A"

  neighbor2 = g.addVertex(player.id + "_2")
  neighbor2.active = false
  neighbor2.score = "B"

  neighbor3 = g.addVertex(player.id + "_3")
  neighbor3.active = false
  neighbor3.score = "C"
  
  player.private.score = "You"
  player.text = c.get("Tutorial1")
  
  player.tpoint = 0
  neighbor1.tpoint = 0
  neighbor2.tpoint = 0
  neighbor3.tpoint = 0
  
  g.addEdge(player, neighbor1)
  g.addEdge(player, neighbor2)
  g.addEdge(player, neighbor3)
  
  // Tutorial 2
  a.add(player, [name: "Next", result: {  
    player.text = c.get("Tutorial2")
  }])
  
  
  // Tutorial 3
  a.add(player, [name: "Next", result: {  
    player.text = c.get("Tutorial3", bonusRatio, extraBonus)
  }])
  
  
  // Tutorial 4
  a.add(player, [name: "Next", result: {
    
    player.neighbors.each { neighbor-> 
      player.setProperty("n" + neighbor.id, [:])
      player["n" + neighbor.id].totalTemp = 0
      player["n" + neighbor.id].lastRoundTemp = 0
      player["n" + neighbor.id].total = 0
      player["n" + neighbor.id].lastRound = 0
    }
    player.plainAllocations = true
    
    neighbor1.setProperty("n" + player.id, [:])
    neighbor1["n" + player.id].lastRound = 0
    neighbor1["n" + player.id].total = 0
    neighbor2.setProperty("n" + player.id, [:])
    neighbor2["n" + player.id].lastRound = 0
    neighbor2["n" + player.id].total = 0
    neighbor3.setProperty("n" + player.id, [:])
    neighbor3["n" + player.id].lastRound = 0
    neighbor3["n" + player.id].total = 0
    
    def addText = ""
    if (showInformation == 1){
      player.score2 = 0
      neighbor1.score2 = 0
      neighbor2.score2 = 0
      neighbor3.score2 = 0
      addText = "You will also see how much Internet bandwidth your neighors have received in total (total score), both in the table and in the nodes of the left diagram."
    } else if (showInformation == 2){
      player.score2 = 3
      neighbor1.score2 = 3
      neighbor2.score2 = 6
      neighbor3.score2 = 1
      addText = "You will also see how many residents your neighors can interact with, both in the table and in the nodes of the left diagram."
    }
    if (showInformation == 3){
      addText2 = "how much of your Internet connection you have ever shared with each one of your neighbors, and how much they have ever shared with you since the first round."
    } else{
      addText2 = "how much of your Internet connection you shared with each one of your neighbors, and how much they shared with you in the last round."
    }
    
    player.text = c.get("Tutorial4", addText, addText2)
  }])
  
  // Tutorial 5
  a.add(player, [name: "Next", result: {
    player.plainAllocations = false
    player.showAllocations = true
    player.text = c.get("Tutorial5", player.resource)  //resource
  }])
  
  
  // Tutorial 6
  a.add(player, [name: "Share", result: {params->
    println(params)//br: add to observe the params in tutorial 6
    def data1 = ["pid": player.id,
                "pround" : 0]
    params.each { k, v ->         
       if (v instanceof Integer) {
       }else{
        // v = Integer.decode(v)
         v = Float.valueOf(v).toInteger() //br: get value from string
       }
  	   data1[k] = v
       player["n" + k].totalTemp += v 
       player["n" + k].lastRoundTemp = v
    }
    a.addEvent("practice_distributeBW", data1)
    neighbor1.lastRoundTmp = 20
    neighbor2.lastRoundTmp = 6
    neighbor3.lastRoundTmp = 5
    neighbor1.totalTmp = 20
    neighbor2.totalTmp = 6
    neighbor3.totalTmp = 5

    
    
    player.showAllocations = false
    player.waitAllocations = true

    player.text2 = "<p><strong>Please wait... other players are under consideration.</strong></p>"
		
    //Animation of giving bandwidth
    player.neighbors.each { neighbor->
      if (player["n" + neighbor.getId()].lastRoundTemp > 0){
	   //br : rewrite this part:
      g.getEdge(player, neighbor).private(player, ["animate" : "1"+ "," +player["n" + neighbor.getId()].lastRoundTemp + "," + player.getId() + "," + neighbor.getId()])        
    
      
      }
    }
    
    def timer_t = new Timer()
    def startTutorialResultStep = timer_t.runAfter(tn) { // br: this time interval is between allocation and showing the result in evening in practice for dayone
    
      player.waitAllocations = false
      player.resultAllocations = true
      
      player.evening = true
      neighbor1.evening = true
      neighbor2.evening = true
      neighbor3.evening = true
      player.text2 = ""
      
      neighbor1["n" + player.id].lastRound = neighbor1.lastRoundTmp
      neighbor2["n" + player.id].lastRound = neighbor2.lastRoundTmp
      neighbor3["n" + player.id].lastRound = neighbor3.lastRoundTmp
      neighbor1["n" + player.id].total += neighbor1.lastRoundTmp
      neighbor2["n" + player.id].total += neighbor2.lastRoundTmp
      neighbor3["n" + player.id].total += neighbor3.lastRoundTmp
      
      player.neighbors.each { neighbor->
        player["n" + neighbor.id].total = player["n" + neighbor.id].totalTemp
        player["n" + neighbor.id].lastRound = player["n" + neighbor.id].lastRoundTemp

        //Animation of giving bandwidth
	    if (neighbor.lastRoundTmp > 0){          
          
        //br : rewrite this part:
          g.getEdge(player, neighbor).private(player, ["animate" : "1"+ "," +neighbor.lastRoundTmp + "," + neighbor.getId() + "," + player.getId()])
    
          
        } 
      }
       
      player.tpoint += neighbor1.lastRoundTmp + neighbor2.lastRoundTmp + neighbor3.lastRoundTmp
      neighbor1.tpoint += 15 + player["n" + neighbor1.id].lastRound
      neighbor2.tpoint += 30 + player["n" + neighbor2.id].lastRound
      neighbor3.tpoint += player["n" + neighbor3.id].lastRound
      if (showInformation == 1){
      	player.score2 = player.tpoint 
        neighbor1.score2 += neighbor1.tpoint
        neighbor2.score2 += neighbor2.tpoint
        neighbor3.score2 += neighbor3.tpoint
      }
      
      player.text = c.get("Tutorial6", player.tpoint, bonusRatio, currency.format(player.tpoint * bonusRatio))
      
      // Tutorial 7
	  a.add(player, [name: "Next", result: {
        player.evening = false
        neighbor1.evening = false
        neighbor2.evening = false
        neighbor3.evening = false
    	player.resultAllocations = false
    	player.showAllocations = true
    	player.text = c.get("Tutorial7", player.resource, player.tpoint, currency.format(player.tpoint * bonusRatio))//c.get("Tutorial7", resource, player.tpoint, currency.format(player.tpoint * bonusRatio))
  	  }])
      
      // Tutorial 8
      //get variance resource
          k = Math.random()  
          kk = (( k < 0.5) ? -1 : 1) * k//br: get a random -1~1 number

         player.variance = variance * kk    
         player.resource = Math.round(resource + player.variance - 0.5)
      
      a.add(player, [name: "Share", result: {params2->
        //println(params)
        def data2 = ["pid": player.id,
                "pround" : 1]
        params2.each { k, v ->         
          if (v instanceof Integer) {
          }else{
            //v = Integer.decode(v)
            v = Float.valueOf(v).toInteger() //br: change the var type into float.
          }
  	      data2[k] = v
          player["n" + k].totalTemp += v 
          player["n" + k].lastRoundTemp = v
        }
        a.addEvent("practice_distributeBW", data2)
        neighbor1.lastRoundTmp = 14
        neighbor2.lastRoundTmp = 6
        neighbor3.lastRoundTmp = 15
        neighbor1.totalTmp += 14
        neighbor2.totalTmp += 6
        neighbor3.totalTmp += 15

        player.showAllocations = false
        player.waitAllocations = true

        player.text2 = "<p><strong>Please wait... other players are under consideration.</strong></p>"
		
        //Animation of giving bandwidth
        player.neighbors.each { neighbor->
          if (player["n" + neighbor.getId()].lastRoundTemp > 0){
	        //g.getEdge(player, neighbor).private(player, ["animate" : player["n" + neighbor.getId()].lastRoundTemp + "," + player.getId() + "," + neighbor.getId() + ",p2"])
         //br: rewrite
           g.getEdge(player, neighbor).private(player, ["animate" : "1"+ "," +player["n" + neighbor.getId()].lastRoundTemp + "," + player.getId() + "," + neighbor.getId()])
        
          }
        }
    
        def timer_t2 = new Timer()
        def startTutorialResultStep2 = timer_t2.runAfter(tn) {//br: time interval between allocation and showing result in daytwo practice
    
          player.waitAllocations = false
          player.resultAllocations = true
      
          player.evening = true
          neighbor1.evening = true
          neighbor2.evening = true
          neighbor3.evening = true
          player.text2 = ""
      
          neighbor1["n" + player.id].lastRound = neighbor1.lastRoundTmp
          neighbor2["n" + player.id].lastRound = neighbor2.lastRoundTmp
          neighbor3["n" + player.id].lastRound = neighbor3.lastRoundTmp
          neighbor1["n" + player.id].total += neighbor1.lastRoundTmp
          neighbor2["n" + player.id].total += neighbor2.lastRoundTmp
          neighbor3["n" + player.id].total += neighbor3.lastRoundTmp
      
          player.neighbors.each { neighbor->
            player["n" + neighbor.id].total = player["n" + neighbor.id].totalTemp
            player["n" + neighbor.id].lastRound = player["n" + neighbor.id].lastRoundTemp

            //Animation of giving bandwidth
        //Animation of giving bandwidth
	    if (neighbor.lastRoundTmp > 0){          
          
        //br : rewrite this part:
          g.getEdge(player, neighbor).private(player, ["animate" : "1"+ "," +neighbor.lastRoundTmp + "," + neighbor.getId() + "," + player.getId()])
    
          
        } 
          }
       
          player.tpoint += neighbor1.lastRoundTmp + neighbor2.lastRoundTmp + neighbor3.lastRoundTmp
          neighbor1.tpoint += 9 + player["n" + neighbor1.id].lastRound
          neighbor2.tpoint += 10 + player["n" + neighbor2.id].lastRound
          neighbor3.tpoint += player["n" + neighbor3.id].lastRound
          if (showInformation == 1){
      	    player.score2 = player.tpoint 
            neighbor1.score2 += neighbor1.tpoint
            neighbor2.score2 += neighbor2.tpoint
            neighbor3.score2 += neighbor3.tpoint
          }
      
          player.text = c.get("Tutorial8", player.tpoint, currency.format(player.tpoint * bonusRatio))
      
          // Tutorial 9
	      a.add(player, [name: "Next", result: {
            player.evening = false
            neighbor1.evening = false
            neighbor2.evening = false
            neighbor3.evening = false
            player.resultAllocations = false
            def extraText = ""
            if (removeDropped){
            	extraText = "If your neighbor is dropped, she or he will no longer show up in the table and in the diagram to the left." 
            }
              
    	    player.text = c.get("Tutorial9", bonusRatio, extraBonus, extraText)
  	      }])
      
          // Tutorial 10
	      a.add(player, [name: "Next", result: {
            player.score2 = ""
            player.tpoint = 0
            g.removePlayer(neighbor1.id)
            g.removePlayer(neighbor2.id)
            g.removePlayer(neighbor3.id)
    	   player.text = c.get("Tutorial10")
          
            confirmationTest(player)
          }])
          
    
          } //def startTutorialResultStep2 = timer_t.runAfter(4500) {
        }])
      
        
  	    
        
    
    } //def startTutorialResultStep = timer_t.runAfter(4500) {

  }])
  
}

def confirmationTest(player){
  
  println "Confirmation start"
  // commented-out by George on August 29
  //def neighbor1 = g.getVertex(player.id + "_1")
  //def neighbor2 = g.getVertex(player.id + "_2")
  //def neighbor3 = g.getVertex(player.id + "_3")
  //def neighbor4 = g.getVertex(player.id + "_4")
  //def neighbor5 = g.getVertex(player.id + "_5")
  
  def neighbor1 = g.addVertex(player.id + "_1")
  neighbor1.active = false;  
  def neighbor2 = g.addVertex(player.id + "_2")
  neighbor2.active = false;  
  def neighbor3 = g.addVertex(player.id + "_3")
  neighbor3.active = false;  
  def neighbor4 = g.addVertex(player.id + "_4")
  neighbor4.active = false;  
  def neighbor5 = g.addVertex(player.id + "_5")
  neighbor5.active = false; 
  
  
  // commented-out by George on August 29
  //neighbor1 = g.addVertex(player.id + "_1")
  //neighbor2 = g.addVertex(player.id + "_2")
  //neighbor3 = g.addVertex(player.id + "_3")
  //neighbor4 = g.addVertex(player.id + "_4")
  //neighbor5 = g.addVertex(player.id + "_5")
  
  neighbor1.score = "Y"
  neighbor2.score = "A"
  neighbor3.score = "L"
  neighbor4.score = "E"
  neighbor5.score = "U"
  if (showInformation == 1){
    neighbor1.score2 = "35"
    neighbor2.score2 = "142"
    neighbor3.score2 = "20"
    neighbor4.score2 = "100"
    neighbor5.score2 = "56"
  } else if (showInformation == 2){
    neighbor1.score2 = "3"
    neighbor2.score2 = "5"
    neighbor3.score2 = "1"
    neighbor4.score2 = "10"
    neighbor5.score2 = "3"  	
  }
  
  
  
  def alist = [0, 1, 2]
  Collections.shuffle(alist)
  
  def answers1 = ["Total Internet (Mbps) you have received.",
  				  "Total Internet (Mbps) you have given.",
                  "Total Internet (Mbps) you have not given."]
  
  // Test 1
  a.add(player, [name: "Next", result: {
    Collections.shuffle(alist)
    player.text = c.get("Test1", answers1[alist[0]], answers1[alist[1]], answers1[alist[2]])
  }])
  
  def labels = ["A1","A2","A3"]
  def choices = [] 
  for (j in 0..2) {
  	def curColor = j        
    def choice = [
      name: labels[curColor],
      class: "color0",        
      result : {
        def result1 = true
      	if (alist[curColor] != 0) {
        	player.text = c.get("Test1", answers1[alist[0]], answers1[alist[1]], answers1[alist[2]]) + "<h3 style='text-align: center;'><strong>Incorrect!</strong></h3>"
        	player.passed = false
            //player.active = false
            result1 = false
        } else {
            player.text = c.get("Test1", answers1[alist[0]], answers1[alist[1]], answers1[alist[2]]) + "<h3 style='text-align: center;'><strong>Correct!</strong></h3>"
        }
        a.addEvent("Test1", 
	      ["pid" : player.id,
    	   "passed" : result1,
           "answer": answers1[alist[curColor]]])
      }]
   	 choices << choice  
  }
  a.add(player, {}, *choices)
  
  def answers2 = ["You have to make the sharing decision within 90 seconds.",
  				  "You have to share all your Internet in each round.",
                  "You have to make coffee every morning."]
  
  // Test 2
  a.add(player, [name: "Next", result: {
    Collections.shuffle(alist)
    player.text = c.get("Test2", answers2[alist[0]], answers2[alist[1]], answers2[alist[2]])
  }])
  
  choices = [] 
  for (j in 0..2) {
  	def curColor = j        
    def choice = [
      name: labels[curColor],
      class: "color0",        
      result : {
        def result2 = true
      	if (alist[curColor] != 0) {
        	player.text = c.get("Test2", answers2[alist[0]], answers2[alist[1]], answers2[alist[2]]) + "<h3 style='text-align: center;'><strong>Incorrect!</strong></h3>"
        	player.passed = false
            //player.active = false
            result2 = false
        } else {
            player.text = c.get("Test2", answers2[alist[0]], answers2[alist[1]], answers2[alist[2]]) + "<h3 style='text-align: center;'><strong>Correct!</strong></h3>"
        }
        a.addEvent("Test2", 
	      ["pid" : player.id,
    	   "passed" : result2,
           "answer": answers2[alist[curColor]]])
      }]
   	 choices << choice  
  }
  a.add(player, {}, *choices)
  
  def a3 = "Player 'E' is one of players with whom you can share your Internet."
  if (showInformation == 1){
  	a3 = "Player 'E' has received 100 Mbps in total."
  }else if (showInformation == 2){
  	a3 = "Player 'E' has 10 neighbors, including you." 
  }
  
  def answers3 = [a3,
  				  "There are only five players in the entire network.",
                  "Your neighbors can interact with you only."]
  
  // Test 3
  a.add(player, [name: "Next", result: {
    Collections.shuffle(alist)
    if (showInformation == 1){
      player.score2 = "150"
    }else if (showInformation == 2){
      player.score2 = "5"
    }
    g.addEdge(player, neighbor1)
    g.addEdge(player, neighbor2)
    g.addEdge(player, neighbor3)
    g.addEdge(player, neighbor4)
    g.addEdge(player, neighbor5)
    
    player.text = c.get("Test3", answers3[alist[0]], answers3[alist[1]], answers3[alist[2]])
  }])
  
  choices = [] 
  for (j in 0..2) {
  	def curColor = j        
    def choice = [
      name: labels[curColor],
      class: "color0",        
      result : {
        def result3 = true
      	if (alist[curColor] != 0) {
        	player.text = c.get("Test3", answers3[alist[0]], answers3[alist[1]], answers3[alist[2]]) + "<h3 style='text-align: center;'><strong>Incorrect!</strong></h3>"
        	player.passed = false
            //player.active = false
            result3 = false
        } else {
            player.text = c.get("Test3", answers3[alist[0]], answers3[alist[1]], answers3[alist[2]]) + "<h3 style='text-align: center;'><strong>Correct!</strong></h3>"
        }
        a.addEvent("Test3", 
	      ["pid" : player.id,
    	   "passed" : result3,
           "answer": answers3[alist[curColor]]])
      }]
   	 choices << choice  
  }
  a.add(player, {}, *choices)
  
  a.add(player, [name: "Next >", result: {
    player.score2 = ""
    for (i in 1..5) {
    	def neighbor = g.getVertex(player.id + "_" + i)
      	if (neighbor != null) {
        	g.removePlayer(neighbor.id)
      	}     
    }
    
	if (player.passed) {
        numPass++
    	println("Confirmation passed: " + numPass)
	    player.passTest = true
      	//if (startAt == null) {
      	//	startAt = new Date().getTime() + 10000
      	//}
    	//player.timer2 = "The game will start in: ," + startAt + ",message"
    	player.text = c.get("PleaseWait")
        a.addEvent("PlayerWaiting", 
        	["pid" : player.id])
  	}else{
	    println "Confirmation failed"
        player.passTest = false
      	player.text = c.get("GameEnd3", getSubmitForm(player.id, 0, "FailedConfirmationTest"))
      	player.submitHit = true
        player.active = false
        //player.ready = false
      	a.addEvent("PlayerDroppedSubmit", 
        	["pid" : player.id,
         	"reason" : "FailedConfirmationTest"])
      
  	}
  }])

  
}