graphStep = stepFactory.createStep()

graphStep.run = {
  println "graphStep.run"
  
  a.setDropPlayers(true)
  
  curStep = "GraphStep"
  
  createGraph()
    

  //g.V.filter{it.active}.each { v->
  //  
  //  a.addEvent("PlayerPosition",
  //             ["pid" : v.id,
  //              "x"   : v.posX,
  //              "y"   : v.posY])
  //}

  //def label = 'A'
  
  //g.E.each { edge->
  //  edge.share = 0
  //}
  
  g.V.filter{it.active}.each { player->  
    player.toAdd = 0
    player.point = 0
    def degree = 0
    player.neighbors.each { neighbor-> 
      player.setProperty("n" + neighbor.id, [:])
      player["n" + neighbor.id].totalTemp = 0 // -> if neighbor.id = 1234 then neighbor node = <circle 1="{totalTemp:0..."...
      player["n" + neighbor.id].lastRoundTemp = 0
      player["n" + neighbor.id].total = 0
      player["n" + neighbor.id].lastRound = 0

      degree++
    }
    
    player.degree = degree
    if ((network == 3) || (network == 4)){
      if (degree == 1){
        player.resource = 12
      }else if (degree == 2){
        player.resource = 25
      }else if (degree == 3){
        player.resource = 38
      }else if (degree == 5){
        player.resource = 63
      }
    }else{
      player.resource = resource
    }
    
    //player.score = label++
    player.score = player.nodeLabel
    if (showInformation == 1){
      player.score2 = player.point
    }else if (showInformation == 2){
      player.score2 = degree
    }
    a.addEvent("PlayerLabel",
               ["pid" : player.id,
                "label"   : player.nodeLabel,
                "degree"   : degree,
                "resource" : player.resource])
    
    if (player.degree == 0){ // remove isolated players
      a.remove(player)
      player.text = c.get("GameEnd2", c.get("TooManyPlayers"), getSubmitForm(player.id, 0, "TooManyPlayers"))
      a.addEvent("PlayerDroppedSubmit",
            ["pid" : player.id,
             "reason" : "IsolatedPlayers"])
      player.active = false
    }
    
  }
  
}

graphStep.done = {
  println "graphStep.done"
  curRound = 1
  sharingStep.start()
}