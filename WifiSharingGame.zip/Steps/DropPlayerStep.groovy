a.setDropPlayers(true)
a.setIdleTime(timeIdle)  // br: this is the idle time for each player in second. change it from 45 to timeIdle.
a.setDropPlayerClosure({ player ->
  if (player.active){
    a.addEvent("DropPlayer", ["pid": player.id, "reason":"OverIdleTime", "round":curRound, "removeDropped":removeDropped])
    //player.text = c.get("Dropped")
    player.text = c.get("Dropped2", currency.format(player.point * bonusRatio), getSubmitForm(player.id, (player.point * bonusRatio).round(2), "Dropped"))
    println("Player Dropped: " + player.id + ", " + currency.format(player.point * bonusRatio))
    // player.active = false
    player.dropped = true
    player.showAllocations = false
    player.waitAllocations = false
    player.resultAllocations = false
    player.text2 = ""
    player.private.score = ""
    player.private.score2 = ""
  
    if (removeDropped){
      
      player.neighbors.each { neighbor->
        neighbor.degree = neighbor.degree - 1
        //for zero-degree neighbor to be dropped with bonus
        if (neighbor.degree == 0){              
          neighbor.text2 = ""
    	  neighbor.resultAllocations = false
          neighbor.showAllocations = false
          neighbor.waitAllocations = false
          neighbor.resultAllocations = false
          neighbor.dropped = true
          neighbor.active = false

          neighbor.text = c.get("GameEnd", currency.format(neighbor.point * bonusRatio), currency.format(extraBonus), currency.format((neighbor.point * bonusRatio) + extraBonus), getSubmitForm(neighbor.id, ((neighbor.point * bonusRatio) + extraBonus).round(2), "GameEnd2"))
	      a.addEvent("DropPlayer", ["pid": neighbor.id, "reason":"ZeroDegree", "round":curRound, "removeDropped":removeDropped])
          a.addEvent("PlayerBonus", ["pid" : neighbor.id,
                               "bonus": (neighbor.point * bonusRatio).round(2),
                               "totalBonus": ((neighbor.point * bonusRatio) + extraBonus).round(2)])
              
          //g.removePlayer(neighbor.id)

            	
        }     
      
        if (showInformation == 2){
            neighbor.score2 = neighbor.degree                
        }//if (showInformation == 2){
      }
      
      player.active = false
      //g.removePlayer(player.id)
      player.getEdges(Direction.BOTH, "connected").each { g.removeEdge(it) }
      a.remove(player.id)
      
      
    }else{ //if (removeDropped){
       // take over the player with AI who always gives 0 to everyone
       a.ai.add(player, { ai ->
         if (player.getProperty("choices")) {
           def choices = player.getProperty("choices")
           def choice = choices[r.nextInt(choices.size())]
           def params = [:]
           if (curStep == "SharingStep") {
             //def remainingBandwidth = 20
             ai.neighbors.shuffle.each { neighbor->
               //def allocation = r.nextInt(remainingBandwidth + 1)
               def allocation = 0
               params[neighbor.id] = allocation
               //remainingBandwidth -= allocation
             }
           }
           a.choose(choice.uid, params)
         }
       })
    }
  } //if (player.active){
})