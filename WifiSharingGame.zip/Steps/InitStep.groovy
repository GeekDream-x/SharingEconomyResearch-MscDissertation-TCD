curStep = "JoinStep"

initStep = stepFactory.createStep()

initStep.run = {
  curStep = "InitStep"
  println "initStep.run"
  
  
  a.addEvent("InitParameters", 
  ["n" : n,
   "nAI": nAi,
   "nRounds": nRounds,
   "connectivity" : connectivity,
   "showInformation" : showInformation,
   "bonusRatio" : bonusRatio,
   "extraBonus" : extraBonus,
   "resource":resource,    ///"resource":resource,
   "geoID":geoID,
   "network":network])
  

  
  g.V.filter{ (it.passTest != null) && (it.passTest)}.each { player->    
    a.add(player, 
      [name: "Ready",
        result: {
          player.active = true
          player.text += "<p>Thank you for clicking Ready, the game will begin momentarily.</p><p>Please wait a little while.</p>"
        },
        event: [name: "ReadyClicked", data: [pid: player.id]]])
  }
  
  // br: add AI strategy 
  g.addAI(a, nAi, { ai ->
    ai.active = true
    //ai.point = 0
    if (ai.getProperty("choices")) {
      def choices = ai.getProperty("choices")
      def choice = choices[r.nextInt(choices.size())]
      def params = [:]
      
      //==================
      
      k = Math.random()  
      kk = (( k < 0.5) ? -1 : 1) * k//br:get a random -1~1 number
      
        
      ai.variance = variance * kk    //br:get a random variance value
      ai.resource = Math.round(resource + ai.variance-0.5)   //br: Math.round(0.855559-0.5)
         
      println('round ' + curRound + "AIplayer" + ai.id + " variance resource:   "+ ai.resource)
    
      
      //==================
      
      if (curStep == "SharingStep" && curRound == 1) {  // br: the first round AI equaly allocate source.
        
        def remainingBandwidth = ai.resource//resource.br: copy the AI resource to the remainingBandwidth variable
        //println('curRound > 1 ai resource:   ' + remainingBandwidth)
        
        
        //xu:initiate the record variable
        ai.remaining = ai.resource
        
		//System.out.println('round 1 ai.remaining:' + ai.remaining)       
        
        
        //xu:print the current assigned resources
        println('round ' + curRound + "AIplayer" + ai.id + " total resource:   "+ ai.resource)
        
                
        //println('remainingBandwidth')
        nn = 1 / ai.neighbors.count()  //br: count the how many neighbors ai has, and nn is the percentage of each AI

        allocation = remainingBandwidth * nn  // br: the points each AI's neighbour could get at first round
               
       	ai.neighbors.each { neighbor->
         
          
          //System.out.println(allocation.getClass().getSimpleName())  //br: check the type of var         
          
          params[neighbor.id] = Math.round(allocation - 0.5)//br: mapping the allocation value to each neighbour. 
          
          
          //xu:decrease the remaining varible after each allocation
          //.remaining -= params[neighbor.id]
          

          //println('1 round:    ' + "neighbor:   "+ neighbor.id + "get:   " + params[neighbor.id])  //br:print out the allocation in first round to check
          
          //remainingBandwidth -= allocation
        }
        
        //xu:after the first round, print the remaining of resources
        //println('round 1 over, aiPlayer'+ai.id+' remained resources:'+ai.remaining)
      }
      
//==================
      
      
      
      
       if (curStep == "SharingStep" && curRound > 1) { // br: After first round AI allocate source acording to the percentage of previous day.
        def remainingBandwidth = resource
        def allocationResource = ai.resource//resource. br: same as the 1st round, just use different variable name to record the AI resource.
         
        // println('curRound > 1 ai resource:   ' + allocationResource)
         
		
        //xu:print the current assigned resources
        //println('round '+ curRound + ' AIplayer '+ai.id + ' assigned: ' + ai.resource)
         
         
        //xu:update the total resource amount         
         ai.resource += ai.remaining
         ai.remaining = ai.resource
         
         
         println('round ' + curRound + "AIplayer" + ai.id + " total resource:   " + ai.resource)

         
        
       	ai.neighbors.each { neighbor->
     
          //println ('curStep == "SharingStep" && curRound > 1')
          ppid = ai.getId()  // br: get the Id of AI          
          //println(ppid)
          
          nnid = neighbor.getId()  //br: get the ID of the neigbor 
          
          // br: get the percentage from the list perList with the key combine with the information: which round which AI player paring which neighour.
          
          pper = perList[("round_" + (curRound-1) + "pid_" + ppid + "nid_" + nnid)]  
          
          //println(pper)  // br: check the list.         
         
          
          allocation = Math.round(allocationResource * pper - 0.5)    // br: this round allocation decided by the perivous percentage 
          
          
          
          
          //println('round  ' + curRound + 'neighbor:    '+ nnid + 'could get:  ' + allocation)  //br: check the points allocating to every neighbor

          //println('new' + allocation)  //br
          
          //System.out.println(allocation.getClass().getSimpleName())  //br: check the type of the var
          
          
          params[neighbor.id] = allocation  //br: out the allocation to 
          remainingBandwidth -= allocation  // br: get the remaining bandwidth
          
          
          //xu:decrease the remaining varible after each allocation, this is not supposed to be here because in the SharingStep, we will do the same thing to every player including real players and AI players
          //ai.remaining -= allocation
          
          
          //xu:check how many times the remaining has been cut down
          //println('----------')
          //println('$$$$$$$$$real player remaining:' + ai.remaining)
          //println('----------')
          
          
          
          
        }
        
         
      	
       }
//========================
      a.choose(choice.uid, params)
    }
  })  //br: end of AI strategy
  
  
  def timer = new Timer()
  def startGameTask = timer.runAfter(tn1) {  //br: time to begain the game after init vars. could be short. couldn't commend out.there will be  no time to wait ready
    println("startGameTask")
    
    // Let's get rid of players who are not ready
    g.V.filter{ ((it.active == null) ||  (!it.active)) && ((it.submitHit == null) || (!it.submitHit))}.each { unready ->
      println("Unready player: " + unready.id)
      unready.active = false
      unready.plainAllocations = false
      unready.showAllocations = false
      unready.waitAllocations = false
      a.remove(unready)
	  unready.text = c.get("Unready")
      a.addEvent("PlayerDroppedReturn",
        ["pid" : unready.id,
         "reason" : "PlayerUnready"])
      
      // Remove dummy players
      for (i in 1..5) {
        def dummy = g.getVertex(unready.id + "_" + i)
        if (dummy != null) {
          g.removePlayer(dummy.id)
        }
      }
    }
  
  
   

  
    def readyPlayers = g.V.filter{it.active}.shuffle.toList()
    if (readyPlayers.size() >= n) {

      if (readyPlayers.size() > n) {
        // We need to drop some ready players here
        //for (def i = (n - nAi); i < readyPlayers.size(); i++) {
        for (def i = n; i < readyPlayers.size(); i++) {  
          def readyPlayer = readyPlayers.get(i)
          a.remove(readyPlayer)
          readyPlayer.text = c.get("GameEnd2", c.get("TooManyPlayers"), getSubmitForm(readyPlayer.id, 0, "TooManyPlayers"))
          a.addEvent("PlayerDroppedSubmit",
            ["pid" : readyPlayer.id,
             "reason" : "TooManyPlayers"])
          readyPlayer.active = false
          //g.removePlayer(readyPlayer)
        }
      }
    
      //start graphStep
	  graphStep.start()
    
  
    }else { // if (readyPlayers + nAi >= n) {
      println("readyPlayers + nAi < n")
      g.V.filter{ (it.active != null) && (it.active)}.each { player ->
        a.remove(player)
        player.text = c.get("GameEnd2", c.get("NotEnoughPlayers"), getSubmitForm(player.id, 0, "NotEnoughPlayers"))
        player.active = false
        a.addEvent("PlayerDroppedSubmit",
          ["pid" : player.id,
           "reason" : "NotEnoughPlayers"])
        //g.removePlayer(player)
      }
    }  

   //}  //br:add new timer
  }//br:tthis is the end of def startGameTask = timer.runAfter(30000)
  
}
initStep.done = {
  println "initStep.done"
 
  

}